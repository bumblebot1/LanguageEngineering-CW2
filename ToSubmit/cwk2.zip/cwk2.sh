./antlr3 camle -hs $1
